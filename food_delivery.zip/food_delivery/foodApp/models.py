from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Customer(models.Model):
    user = models.ForeignKey(User,models.CASCADE)
    name = models.CharField(max_length=100,null=True,blank=True)
    points = models.IntegerField(default=0)
    
    
    def __str__(self):
        return self.user.username

class Staff(models.Model):
   
    user = models.ForeignKey(User,models.CASCADE)
##    staff_id = models.IntegerField(null=True,blank=True)
    name = models.CharField(max_length=100,null=True,blank=True)
    mobile = models.IntegerField(null=True,blank=True)
    email = models.CharField(max_length=200,null=True,blank=True)
    approval = models.BooleanField(default=False)
    profile_pic = models.ImageField(upload_to='staff_profile/',null=True,blank=True)
    points = models.IntegerField(default=0)
    date = models.DateTimeField(auto_now_add=True,null=True,blank=True)
    
    
    def __str__(self):
        return self.name

class Driver(models.Model):
    user = models.ForeignKey(User,models.CASCADE)
    name = models.CharField(max_length=100,null=True,blank=True)
##    orders = models.ManyToManyField('Order',related_name='driver_orders')
    mobile = models.IntegerField(null=True,blank=True)
    email = models.CharField(max_length=200,null=True,blank=True)
    approval = models.BooleanField(default=False)
##    profile_pic = models.ImageField(upload_to='staff_profile/',null=True,blank=True)
##    points = models.IntegerField(default=0)
    date = models.DateTimeField(auto_now_add=True,null=True,blank=True)

    def __str__(self):
        return self.name
    
class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class Restaurant(models.Model):
    name = models.CharField(max_length=100)
    category = models.ForeignKey(Category,models.CASCADE,null=True,blank=True)
    ratings = models.IntegerField(default=0,null=True)
    photo = models.ImageField(upload_to='menu/')
    url = models.URLField(max_length=250,null=True,blank=True)
    location = models.CharField(max_length=250)

    def __str__(self):
        return self.name
    
class Menu(models.Model):
    name = models.CharField(max_length=100)
    restaurant = models.ForeignKey(Restaurant,models.CASCADE)
    photo = models.ImageField(upload_to='menu/')
    
    price = models.DecimalField(decimal_places=2,max_digits=7)
    

    def __str__(self):
        return self.name

class Coupon(models.Model):
    code = models.CharField(max_length=50,null=True,blank=True)
    points = models.IntegerField()
    food = models.ManyToManyField(Menu,related_name='coupon_food')
    image = models.ImageField(upload_to='coupon/',null=True,blank=True)
##    restaurant = models.ForeignKey(Restaurant,models.CASCADE)
    expiry_date = models.DateField()

    def __str__(self):
        return 'Coupon '+str(self.code)

##    def save(self, *args, **kwargs):
##       self.code = 'C000'+str(self.id)
####       self.code.save()
##       super(Coupon, self).save(*args, **kwargs)
    
class Order(models.Model):
    PAYMENT_OPTIONS = (
        ('VISA','VISA'),
        ('Master','Master'),
        ('Octopus','Octopus'),
        ('Cash','Cash'),
    )
    STATUS = (
        ('Pending','Pending'),
        ('Approved','Approved'),
        ('On the way','On the way'),
        ('Delivered','Delivered'),
        ('Completed','Completed'),
    )
    METHODS = (
        ('外賣自取','外賣自取'),
        ('送遞','送遞'),
    )
    user = models.ForeignKey(User,models.CASCADE,null=True,blank=True)
    customer = models.CharField(max_length=200,null=True,blank=True)
    card_id = models.IntegerField(null=True,blank=True)
    code = models.CharField(max_length=10,null=True,blank=True)
    mobile = models.IntegerField(null=True,blank=True)
    email = models.CharField(max_length=200,null=True,blank=True)
    total_price = models.DecimalField(decimal_places=2,max_digits=7)
    payment_method = models.CharField(max_length=50,choices=PAYMENT_OPTIONS,null=True,blank=True)
    driver = models.ForeignKey(Driver,models.CASCADE,null=True,blank=True)
    status = models.CharField(max_length=50,choices=STATUS,default='Pending')
    take_method = models.CharField(max_length=50,choices=METHODS,null=True,blank=True)
    points_earned = models.IntegerField(default=0)
    date = models.DateTimeField(auto_now_add=True)
    address = models.CharField(max_length=350,null=True,blank=True)

##    def save(self,commit=True):
##        new_order = super(Order,self).save(commit=False)
##        new_order.code = 'K00'+str(self.new_order.id)
##        if commit:
##            new_order.save()
        
    def __str__(self):
        return str(self.customer)+'\'s Order'
    
class OrderDetail(models.Model):
    order = models.ForeignKey(Order,models.CASCADE)
    product =  models.ForeignKey(Menu,models.CASCADE)
    unit_price = models.IntegerField(default=0)
    quantity = models.IntegerField(default=0)
    total_price = models.IntegerField(default=0)

    def __str__(self):
        return str(self.order.customer)+'\'s --- '+str(self.product.name)+' x '+str(self.quantity)

class CouponExchange(models.Model):
    user = models.ForeignKey(User,models.CASCADE,null=True,blank=True)
    customer = models.CharField(max_length=200,null=True,blank=True)
    order = models.ForeignKey(Order,models.CASCADE,null=True,blank=True)
    coupon = models.ForeignKey(Coupon,models.CASCADE,null=True,blank=True)
    exchange_points = models.IntegerField()
    

    def __str__(self):
        return str(self.order.code)+' --- Exchanged Coupon'
    
