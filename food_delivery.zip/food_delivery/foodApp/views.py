from django.shortcuts import render,redirect
from .forms import *
from django.contrib.auth import login,authenticate,logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.db.models import F
from django.contrib.auth.models import Group,User

# Create your views here.

#Roles
def is_customer(user):
    return user.groups.filter(name='CUSTOMER').exists()
def is_staff(user):
    return user.groups.filter(name='STAFF').exists()
def is_driver(user):
    return user.groups.filter(name='DRIVER').exists()

#Homepage
def index(request):
    delivered_orders = Order.objects.filter(user=request.user,status='Delivered')
    num_orders = delivered_orders.count()
##    print(num_orders)
    if delivered_orders.exists():
        message = '您好! 您有'+str(num_orders)+'個訂單已到貨了!'
        messages.success(request,message)
    
    return render(request,'index.html')

#List of items
def menu_list(request):
    menu_all = Menu.objects.all()
    
    context = {'menu_all':menu_all}
    return render(request,'menu/menu_list.html',context)

def category_list(request):
    categories = Category.objects.all()
    
    context = {'categories':categories}
    return render(request,'menu/category_list.html',context)

def category_selection(request,category_id):
    category_selected = Category.objects.get(id=category_id)
    restaurants = Restaurant.objects.filter(category=category_selected).values_list('name')
##    print(restaurants)
    restaurant_list = []
    for restaurant in restaurants:
##        print(restaurant[0])
        restaurant_list.append(restaurant[0])
        
##        print(restaurant_list)
    food_list = []
    for restaurant in restaurant_list:
##        print(restaurant)
        restaurant_filter = Restaurant.objects.get(name=restaurant)
##        print(restaurant_filter)
        food_item = Menu.objects.filter(restaurant=restaurant_filter)
        
        food_list.append(food_item)
    foods = list(food_list)
    items_list = []
    for item in foods:
        for restaurant_food in item:
            food = Menu.objects.get(name=restaurant_food)
##            print(food)
            items_list.append(food)
    print(items_list)
    context = {'items_list':items_list,'category_selected':category_selected}
    return render(request,'menu/category_list.html',context)
    
def add_category(request):
    form = CategoryForm()
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    context = {'form':form}
    return render(request,'menu/add_category.html',context)

def add_food(request):
    form = MenuForm()
    if request.method == 'POST':
        form = MenuForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('menu_list')
    context = {'form':form}
    return render(request,'menu/add_food.html',context)

def restaurant_list(request):

    restaurants = Restaurant.objects.all()
    context = {'restaurants':restaurants}
    return render(request,'restaurant/restaurant_list.html',context)

def restaurant_filter(request):
    if request.method == 'GET':
        favorite = request.GET.get('favorite','')
        restaurants = Restaurant.objects.filter(name__icontains=favorite)
        print(restaurants)
    context = {'restaurants':restaurants}
    return render(request,'restaurant/restaurant_list.html',context)
    
def add_restaurant(request):
    form = RestaurantForm()
    if request.method == 'POST':
        form = RestaurantForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('restaurant_list')
    context = {'form':form}
    return render(request,'restaurant/add_restaurant.html',context)

#Coupon
def add_coupon(request):
    form = CouponForm()
    if request.method == 'POST':
        form = CouponForm(request.POST,request.FILES)
        if form.is_valid():
            selected_foods = form.cleaned_data['food']
            print(selected_foods)
            food_list = []
            for select in selected_foods:
                food = Menu.objects.get(name=select)
                print(food)
                food_list.append(food)
            print(food_list)
##            
##            for food in selected_food:
##                selected = Menu.objects.get(name=food)
##                food_list.append(selected)
##            print(food_list)
            new_coupon = Coupon.objects.create(
##                food = selected_food.set,
                points = form.cleaned_data['points'],
                image = form.cleaned_data['image'],
                expiry_date = form.cleaned_data['expiry_date'])
            new_coupon.food.set(food_list)
            new_coupon.save()
            Coupon.objects.filter(id=new_coupon.id).update(code='C00'+str(new_coupon.id))
                    
            return redirect('coupon_list',id=request.user.id)
    context = {'form':form}
    return render(request,'coupon/add_coupon.html',context)

def coupon_list(request,id):
    user = User.objects.get(id=id)
    customer = Customer.objects.get(user=user)
##    print(exchanged_user)
    
    user_points = customer.points
    coupons = Coupon.objects.all()
    exchanged_coupon = []
    
    for coupon in coupons:
        if CouponExchange.objects.filter(user=user,coupon=coupon).exists():
            exchanged_coupon.append(coupon)
    print(exchanged_coupon)
##    print(coupons)
##    print(user_points)
##    for coupon in coupons:
##        print(coupon.food.all())
##    user_points = Customer.objects.get(user=User.objects.get(username=request.user)).points
##    if is_customer(request.user):
##        user_points = Customer.objects.get(user=User.objects.get(username=request.user)).points
##    elif is_staff(request.user):
##        staff = User.objects.get(username=request.user)
####        print(staff)
##        user_points = Staff.objects.get(user=staff).points
##        print(user_points)
    context = {'coupons':coupons,'user_points':user_points,'exchanged_coupon':exchanged_coupon}
    return render(request,'coupon/coupon_list.html',context)

      
#Customer,Staff,Driver   
def customer_register(request):
    form = UserForm()
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                form.cleaned_data['username'],
                form.cleaned_data['email'],
                form.cleaned_data['password1'])
            user.save()
            new_customer = Customer.objects.create(
                user = User.objects.get(id=user.id))
            new_customer.save()
            customer_group = Group.objects.filter(name='CUSTOMER').exists()
            if customer_group:
                group = Group.objects.get(name='CUSTOMER')
                user.groups.add(group)
            else:
                Group.objects.create(name='CUSTOMER')
                group = Group.objects.get(name='CUSTOMER')
                user.groups.add(group)
          
            messages.success(request,'註冊成功! 請按指示登入!')
            return redirect('login')
        else:
            messages.error(request,'註冊無效! 請再試過!')
    context = {'form':form}
    return render(request,'customer/register.html',context)

def staff_register(request):
    form = StaffForm()
    extra_form = StaffExtraForm()
    if request.method == 'POST':
        form = StaffForm(request.POST)
        extra_form = StaffExtraForm(request.POST,request.FILES)
        if form.is_valid() and extra_form.is_valid():
            user = User.objects.create_user(
                form.cleaned_data['username'],
                form.cleaned_data['email'],
                form.cleaned_data['password1'])
            user.save()
        
            new_staff = Staff.objects.create(
                user = User.objects.get(id=user.id),
                name = extra_form.cleaned_data['name'],
                mobile = extra_form.cleaned_data['mobile'],
                email = form.cleaned_data['email'],
                profile_pic = extra_form.cleaned_data['profile_pic'],
            )
            new_staff.save()
            
          
            messages.success(request,'註冊成功! 請等待管理員核准!')
            return redirect('login')
        else:
            messages.error(request,'註冊無效! 請再試過!')
    context = {'form':form,'extra_form':extra_form}
    return render(request,'staff/staff_register.html',context)

def driver_register(request):
    form = DriverForm()
    extra_form = DriverExtraForm()
    if request.method == 'POST':
        form = DriverForm(request.POST)
        extra_form = DriverExtraForm(request.POST)
        print(form.is_valid())
        print(extra_form.is_valid())
        if form.is_valid() and extra_form.is_valid():
            user = User.objects.create_user(
                form.cleaned_data['username'],
                form.cleaned_data['email'],
                form.cleaned_data['password1'])
            user.save()
        
            new_driver = Driver.objects.create(
                user = User.objects.get(id=user.id),
                name = extra_form.cleaned_data['name'],
                mobile = extra_form.cleaned_data['mobile'],
                email = form.cleaned_data['email'],
##                profile_pic = extra_form.cleaned_data['profile_pic'],
            )
            new_driver.save()
            
          
            messages.success(request,'註冊成功! 請等待管理員核准!')
            return redirect('login')
        else:
            messages.error(request,'註冊無效! 請再試過!')
    context = {'form':form,'extra_form':extra_form}
    return render(request,'driver/driver_register.html',context)





def login_view(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            messages.info(request,'登入成功!')
            if is_customer(request.user):
                return redirect('user_dashboard',user_id=request.user.id)
            elif is_staff(request.user):
                return redirect('staff_dashboard')
            elif is_driver(request.user):
                return redirect('driver_dashboard')
        else:
            messages.error(request,'帳戶無效或密碼錯誤! 請重試!')
    context = {'form':form}
    return render(request,'login.html',context)


##def staff_login_view(request):
##    form = AuthenticationForm()
##    if request.method == 'POST':
##        form = AuthenticationForm(request, data=request.POST)
##        if form.is_valid():
##            if request.user.is_staff == True:
##                login(request, form.get_user())
##                messages.info(request,'登入成功!')
##                return redirect('index')
##        else:
##            messages.error(request,'帳戶無效或密碼錯誤! 請重試!')
##    context = {'form':form}
##    return render(request,'customer/staff_login.html',context)

def logout_request(request):
    logout(request)
    messages.info(request,'登出成功!')
    return redirect('login')


#Shopping cart
cartlist = []


def add_to_cart(request,menu_id):
    global cartlist
    food = Menu.objects.get(id=menu_id)
    flag = True
    if cartlist:
        for unit in cartlist:
            if food.name == unit[0]:
                unit[2] = str(int(unit[2])+1)
                unit[3] = str(int(unit[3])+int(food.price))
                flag = False
                break
    if flag:
        temlist = []
        temlist.append(food.name)
        temlist.append(str(int(food.price)))
        temlist.append('1')
        temlist.append(str(int(food.price)))
        cartlist.append(temlist)
    request.session['cartlist'] = cartlist
    messages.success(request,'成功加入購物車!')
    return redirect('cart')

def update_cart(request):
    global cartlist
    n = 0
    for unit in cartlist:
        unit[2] = request.POST.get('qty'+str(n),'1')
        unit[3] = str(int(unit[1])*int(unit[2]))
        n += 1
    request.session['cartlist'] = cartlist
    return redirect('cart')

def remove_item(request,menu_id):
    global cartlist
    del cartlist[int(menu_id)]
    request.session['cartlist'] = cartlist
    return redirect('cart')
    
def empty_cart(request):
    global cartlist,coupon_exchanged
    cartlist = []
    coupon_exchanged = []
    request.session['cartlist'] = cartlist
    return redirect('cart')

def cart(request):
    global cartlist,coupon_exchanged
    print(coupon_exchanged)
    coupon = ''
    if coupon_exchanged:
        coupon = Coupon.objects.get(code=coupon_exchanged[0])
        print(coupon)
    cartlist1 = cartlist
    total = 0
    for unit in cartlist:
        total += int(unit[3])
    grandtotal = total + 100
    context = {
        'cartlist':cartlist1,
        'grandtotal':grandtotal,
        'total':total,
        'coupon':coupon
    }
    return render(request,'menu/cart.html',context)

#Exchange coupon
coupon_exchanged = []

def add_coupon_to_cart(request,coupon_id):
    global coupon_exchanged
    coupon = Coupon.objects.get(id=coupon_id)
##    coupon_unit = []
    coupon_exchanged.append(coupon.code)
    coupon_exchanged.append(coupon.points)
##    coupon_exchanged.append(coupon_unit)
##    print(coupon_exchanged)
##    request.session['couponList'] = coupon_exchanged
##    messages.success(request,'成功將優惠券加入購物車!')
    return redirect('cart')
##    coupon = Coupon.objects.get(id=coupon_id)
##    user = User.objects.get(id=user_id)
##    Customer.objects.filter(user=user).update(points=F('points')-coupon.points)
##    return redirect('coupon_list',id=user.id)

#Transaction history
def order_summary(request,order_id):
##    user = User.objects.get(id=user_id)
    customer_order = Order.objects.get(id=order_id)
    coupon = 'Nil'
##    coupon = []
    print(CouponExchange.objects.filter(user=request.user,order=customer_order).exists())
    if CouponExchange.objects.filter(user=request.user,order=customer_order).exists() == True:
        coupon = CouponExchange.objects.get(order=customer_order).coupon
    
    food_order = OrderDetail.objects.filter(order=customer_order)
    context = {
        'customer_order':customer_order,
        'food_order':food_order,
        'coupon':coupon}
    return render(request,'menu/order_summary.html',context)

def user_transactions(request):
##     user = User.objects.get(id=user_id)
    total_order = Order.objects.all().count()
    pending_order = Order.objects.filter(status='Pending').count()
    approved_order = Order.objects.filter(status='Approved').count()
    coming_order = Order.objects.filter(status='On the way').count()
    user_record = Order.objects.all()
##    print(delivered_order)
    context = {'total_order':total_order,
               'pending_order':pending_order,
               'approved_order':approved_order,
               'coming_order':coming_order,
               'user_record':user_record}
    return render(request,'customer/user_transactions.html',context)

def checkout(request):
    global cartlist,coupon_exchanged
    coupon = coupon_exchanged
    print(coupon)
    cartlist1 = cartlist
    total = 0
    for unit in cartlist:
        total += int(unit[3])
    grandtotal = total + 100
    earnings = int(grandtotal/5)
    print(grandtotal)
    if request.method == 'POST':
##        print(type(request.POST.get('customerPayment')))
##        print(request.POST.get('customerPayment'))
##        print(request.POST.get('customerTakeaway'))
        customerName = request.POST.get('customerName','')
        customerID = request.POST.get('customerID','')
        customerMobile = request.POST.get('customerMobile','')
        customerEmail = request.POST.get('customerEmail','')
        customerPayment = request.POST.get('customerPayment'),
        customerTakeaway = request.POST.get('customerTakeaway'),
        customerAddress = request.POST.get('customerAddress','')
##        print(customerPayment[0])
        new_order = Order.objects.create(
                user = User.objects.get(username=request.user),
                customer = customerName,
                card_id = customerID,
                mobile = customerMobile,
                email = customerEmail,
                total_price = grandtotal,
                payment_method = customerPayment[0],
                take_method = customerTakeaway[0],
                points_earned = earnings,
                address = customerAddress)
        
##        new_coupon = 
        account = User.objects.get(username=request.user)
        current_customer = Customer.objects.filter(user=account)
        if current_customer.exists():
            current_customer.update(points=F('points')+earnings)
        else:
            new_customer = Customer.objects.create(
                user = account,
                name = customerName,
                points = earnings)
            new_customer.save()

        new_order.save()

        if len(str(new_order.id)) == 1:
            new_code = 'K00'+str(new_order.id)
        else:
            new_code = 'K0'+str(new_order.id)
        Order.objects.filter(id=new_order.id).update(code=new_code)

        
        
        for unit in cartlist:
            unit_total = int(unit[1])*int(unit[2])
            unit_order = OrderDetail.objects.create(
                order = new_order,
                product = Menu.objects.get(name=unit[0]),
                unit_price = int(unit[1]),
                quantity = int(unit[2]),
                total_price = unit_total)
            print(unit_order)
            unit_order.save()
            
        if coupon != []:
            new_coupon = Coupon.objects.get(code=coupon[0])
            coupon_data = CouponExchange.objects.create(
                user = User.objects.get(username=request.user),
                customer = customerName,
                order = new_order,
                coupon = new_coupon,
                exchange_points = coupon[1])
            coupon_data.save()
            current_customer.update(points=F('points')-coupon[1])
                
        cartlist = []
        request.session['cartlist'] = cartlist
        messages.success(request,'成功訂單! 請稍後領取')
        return redirect('order_summary',order_id=new_order.id)
        
        
    context = {
        'cartlist':cartlist1,
        'grandtotal':grandtotal,
        'earnings':earnings,
        'total':total,
        'coupon':coupon
    }
    return render(request,'menu/checkout.html',context)






#User Panel
def user_order(request,user_id):
    user = User.objects.get(id=user_id)
    order_filtered = Order.objects.filter(user=user)
 
##    print(order_filtered)
    order_record = {}
    coupon_record = []
##    order_coupon = ''
    for order in order_filtered:
        order_list = []
        ordered = Order.objects.get(id=order.id)
        
        food_order = OrderDetail.objects.filter(order=ordered)
        for food in food_order:
    
            order_list.append(food)
##        print(food_order)
##        print(order_list)
        order_record[ordered] = order_list

        if CouponExchange.objects.filter(order=order).exists():
            exchanged_coupon = CouponExchange.objects.get(order=order)
            order_coupon = exchanged_coupon.coupon
            print(order_coupon)
##            order_record['Coupon Exchanged'] = order_coupon
    print(order_record)
    
  
##    print(food_order)
    context = {'order_record':order_record}
    return render(request,'customer/user_order.html',context)

def user_dashboard(request,user_id):
    user = User.objects.get(id=user_id)
    total_order = Order.objects.filter(user=user).count()
    pending_order = Order.objects.filter(user=user,status='Pending').count()
    delivered_order = Order.objects.filter(user=user,status='Delivered').count()
    coming_order = Order.objects.filter(user=user,status='On the way').count()
    user_record = Order.objects.filter(user=user)
    print(delivered_order)
    context = {'total_order':total_order,
               'pending_order':pending_order,
               'delivered_order':delivered_order,
               'coming_order':coming_order,
               'user_record':user_record}
    return render(request,'customer/user_dashboard.html',context)


def staff_list(request):
    staff_all = Staff.objects.all()
    total_staff = Staff.objects.count()
    pending_staff = Staff.objects.filter(approval=False).count()
    approved_staff = Staff.objects.filter(approval=True).count()
    context = {'staff_all':staff_all,
               'total_staff':total_staff,
               'pending_staff':pending_staff,
               'approved_staff':approved_staff}
    return render(request,'staff/staff_list.html',context)

def staff_approval(request,staff_id):
    staff = Staff.objects.get(id=staff_id)
    staff.approval = True
    staff.save()
##    staff_user = Staff.objects.get(id=staff_id).user
    
    pending_staff = User.objects.get(username=staff)
   
    staff_group = Group.objects.filter(name='STAFF').exists()
    if staff_group:
        group = Group.objects.get(name='STAFF')
        pending_staff.groups.add(group)
    else:
        Group.objects.create(name='STAFF')
        group = Group.objects.get(name='STAFF')
        pending_staff.groups.add(group)
    return redirect('staff_list')

def driver_approval(request,driver_id):
    driver = Driver.objects.get(id=driver_id)
    driver.approval = True
    driver.save()
    driver_user = Driver.objects.get(id=driver_id).user
    
    pending_driver = User.objects.get(username=driver_user)
   
    driver_group = Group.objects.filter(name='DRIVER').exists()
    if driver_group:
        group = Group.objects.get(name='DRIVER')
        pending_driver.groups.add(group)
    else:
        Group.objects.create(name='DRIVER')
        group = Group.objects.get(name='DRIVER')
        pending_driver.groups.add(group)
    return redirect('driver_list')

def approve_order(request,order_id):
    order = Order.objects.get(id=order_id)
    order.status = 'Approved'
    order.save()
    form = OrderApprovalForm()
    if request.method == 'POST':
        form = OrderApprovalForm(request.POST)
        if form.is_valid():
            driver = Driver.objects.get(name=form.cleaned_data['driver'])
            order.driver = driver
            order.save()
            return redirect('staff_dashboard')
    context = {'order':order,'form':form}
    return render(request,'menu/order_approval.html',context)

def receive_order(request,order_id):
    order = Order.objects.get(id=order_id)
    order.status = 'On the way'
    order.save()
    return redirect('driver_dashboard')

def deliver_order(request,order_id):
    order = Order.objects.get(id=order_id)
    order.status = 'Delivered'
    order.save()
    return redirect('driver_dashboard')

def collect_order(request,order_id):
    order = Order.objects.get(id=order_id)
    order.status = 'Collected'
    order.save()
    return redirect('user_order',user_id=request.user.id)
    
def driver_list(request):
    driver_all = Driver.objects.all()
    total_driver = Driver.objects.count()
    pending_driver = Driver.objects.filter(approval=False).count()
    approved_driver = Driver.objects.filter(approval=True).count()
    context = {'driver_all':driver_all,
               'total_driver':total_driver,
               'pending_driver':pending_driver,
               'approved_driver':approved_driver}
    return render(request,'driver/driver_list.html',context)

def customer_profile(request,id):
    user = User.objects.get(id=id)
    customer = Customer.objects.get(user=user)
    total_order = Order.objects.filter(user=user).count()
    coupons = Coupon.objects.all()
    coupons_allowed = []
    for coupon in coupons:
##        print(coupon)
##        print(CouponExchange.objects.filter(coupon=coupon))
        if customer.points >= coupon.points and CouponExchange.objects.filter(user=user,coupon=coupon).exists() == False:
            coupons_allowed.append(coupon)
##    print(coupons_allowed)
    context = {'customer':customer,'total_order':total_order,'coupons_allowed':coupons_allowed}
    return render(request,'customer/customer_profile.html',context)
    
def staff_dashboard(request):
##    user = User.objects.get(id=user_id)
    total_order = Order.objects.count()
    pending_order = Order.objects.filter(status='Pending').count()
    delivered_order = Order.objects.filter(status='Delivered').count()
    collected_order = Order.objects.filter(status='Collected').count()
    order_records = Order.objects.all()
    context = {'total_order':total_order,
               'pending_order':pending_order,
               'delivered_order':delivered_order,
               'collected_order':collected_order,
               'order_records':order_records}
    return render(request,'staff/staff_dashboard.html',context)

def driver_dashboard(request):
    user = User.objects.get(username=request.user)
##    print(user)
    driver = Driver.objects.get(user=user)
    orders = Order.objects.filter(driver=driver)
    print(orders)
##    user = User.objects.get(id=user_id)
    total_order = orders.count()
    pending_order = Order.objects.filter(driver=driver,status='Pending').count()
    delivered_order = Order.objects.filter(driver=driver,status='Delivered').count()
    collected_order = Order.objects.filter(driver=driver,status='Collected').count()
##    order_records = Order.objects.all()
    context = {'total_order':total_order,
               'pending_order':pending_order,
               'delivered_order':delivered_order,
               'collected_order':collected_order,
               'orders':orders}
    return render(request,'driver/driver_dashboard.html',context)



##def order_ready(request,order_id):
##    order = Order.objects.get(id=order_id)
##    order.status = 'Delivered'
##    order.save()
##    return redirect('staff_dashboard')
##    
##def accept_order(request,order_id):
##    order = Order.objects.get(id=order_id)
##    order.status = 'Collected'
##    order.save()
##    return redirect('user_dashboard',user_id=request.user.id)
