from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    #Homepage
    path('',views.index,name='index'),
    path('index/',views.index,name='index'),
    
    #Categories of food and restaurants
    path('menu_list/',views.menu_list,name='menu_list'),
    path('category_list/',views.category_list,name='category_list'),
    path('category_selection/<int:category_id>/',views.category_selection,name='category_selection'),
    path('add_category/',views.add_category,name='add_category'),
    path('add_food/',views.add_food,name='add_food'),
    path('restaurant_list/',views.restaurant_list,name='restaurant_list'),
    path('restaurant_filter/',views.restaurant_filter,name='restaurant_filter'),
    path('add_restaurant/',views.add_restaurant,name='add_restaurant'),
    path('add_coupon/',views.add_coupon,name='add_coupon'),
    path('coupon_list/<int:id>/',views.coupon_list,name='coupon_list'),

    #Customer,Staff,Driver
    path('customer_register/',views.customer_register,name='customer_register'),
    path('staff_register/',views.staff_register,name='staff_register'),
    path('driver_register/',views.driver_register,name='driver_register'),
    path('login/',views.login_view,name='login'),
    path('logout/',views.logout_request,name='logout'),

    #Shopping cart
    path('add_to_cart/<int:menu_id>/',views.add_to_cart,name='add_to_cart'),
    path('add_coupon_to_cart/<int:coupon_id>/',views.add_coupon_to_cart,name='add_coupon_to_cart'),
    
    path('remove_item/<int:menu_id>/',views.remove_item,name='remove_item'),
    path('update_cart/',views.update_cart,name='update_cart'),
    path('empty_cart/',views.empty_cart,name='empty_cart'),
    path('cart/',views.cart,name='cart'),
##    path('update_order/<int:order_id>/',views.update_order,name='update_order'),
##    path('update_item_qty/<int:item_id>/',views.update_item_qty,name='update_item_qty'),
    
    #Transaction 
    path('order_summary/<int:order_id>/',views.order_summary,name='order_summary'),
##    path('order_ready/<int:order_id>/',views.order_ready,name='order_ready'),
    path('checkout/',views.checkout,name='checkout'),

    
    #Delivery Process
    path('approve_order/<int:order_id>/',views.approve_order,name='approve_order'),
##    path('accept_order/<int:order_id>/',views.accept_order,name='accept_order'),
    path('receive_order/<int:order_id>/',views.receive_order,name='receive_order'),
##    path('arrange_driver/<int:order_id>/',views.arrange_driver,name='arrange_driver'),
    path('deliver_order/<int:order_id>/',views.deliver_order,name='deliver_order'),
    path('collect_order/<int:order_id>/',views.collect_order,name='collect_order'),
    
    #Customer
    path('customer_profile/<int:id>/',views.customer_profile,name='customer_profile'),
    path('user_order/<int:user_id>/',views.user_order,name='user_order'),
    path('user_dashboard/<int:user_id>/',views.user_dashboard,name='user_dashboard'),
    path('user_transactions/',views.user_transactions,name='user_transactions'),
    
    #Staff
    path('staff_list/',views.staff_list,name='staff_list'),
    path('staff_approval/<int:staff_id>/',views.staff_approval,name='staff_approval'),
    path('staff_dashboard/',views.staff_dashboard,name='staff_dashboard'),

    #Driver
    path('driver_list/',views.driver_list,name='driver_list'),
    path('driver_approval/<int:driver_id>/',views.driver_approval,name='driver_approval'),
    path('driver_dashboard/',views.driver_dashboard,name='driver_dashboard'),

]
