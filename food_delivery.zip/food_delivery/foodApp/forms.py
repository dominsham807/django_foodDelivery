from django import forms
from django.forms import widgets
##from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = '__all__'
    
class RestaurantForm(forms.ModelForm):
    class Meta:
        model = Restaurant
        fields = '__all__'
        exclude = ['ratings']
    
class MenuForm(forms.ModelForm):
    class Meta:
        model = Menu
        fields = '__all__'

class CouponForm(forms.ModelForm):
    class Meta:
        model = Coupon
        fields = '__all__'
        exclude = ['code']
        widgets = {
            'expiry_date': widgets.DateInput(attrs={'type': 'date'})
        }

##    def save(self,commit=True):
##        new_coupon = super(CouponForm,self).save(commit=False)
##        new_coupon.code = 'C00'+new_coupon
        
class UserForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username','email','password1','password2')

    def save(self,commit=True):
        user = super(UserForm,self).save(commit=False)
        user.set_password = self.cleaned_data['password1']
        user.email = self.cleaned_data['email']
        
        if commit:
            user.save()
        return user

class StaffForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username','email','password1','password2')

    def save(self,commit=True):
        user = super(StaffForm,self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.is_staff = True
        if commit:
            user.save()
        return user

class StaffExtraForm(forms.ModelForm):
    class Meta:
        model = Staff
        fields = ('name','mobile','profile_pic')
    
class DriverForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username','email','password1','password2')

    def save(self,commit=True):
        user = super(DriverForm,self).save(commit=False)
        user.email = self.cleaned_data['email']
##        user.is_staff = True
        if commit:
            user.save()
            

class DriverExtraForm(forms.ModelForm):
    class Meta:
        model = Driver
        fields = ('name','mobile')
            
class LoginForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ('username','password')

class OrderApprovalForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['driver']


    
